import { Header } from "./components/Header";
import { ForecastControls } from "./components/ForecastControls";
import { KpiRow } from "./components/KpiRow";
import { ForecastChart } from "./components/ForecastChart";
import { ProjectionsLedger } from "./components/ProjectionsLedger";
import { ShapPanel } from "./components/ShapPanel";
import { useForecast } from "./hooks/useForecast";
import "./styles/app.css";

export default function App() {
  const {
    models,
    historical,
    activeModelId,
    horizonWeeks,
    forecast,
    shap,
    loadingInitial,
    loadingForecast,
    error,
    setHorizonWeeks,
    generateForecast,
  } = useForecast();

  if (loadingInitial) {
    return (
      <div className="app-shell">
        <Header />
        <main className="app-main">
          <div className="app-loading">Loading FreightAI…</div>
        </main>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <Header />
      <main className="app-main">
        {error && <div className="app-error">⚠ {error}</div>}

        <ForecastControls
          models={models}
          activeModelId={activeModelId}
          horizonWeeks={horizonWeeks}
          onHorizonChange={setHorizonWeeks}
          onModelSelect={(id) => generateForecast(id, horizonWeeks)}
          onRunForecast={() => generateForecast(activeModelId, horizonWeeks)}
          loading={loadingForecast}
        />

        <div className="app-section-gap" />

        <KpiRow forecast={forecast} />

        <div className="app-section-gap" />

        <div className="app-main-grid">
          <ForecastChart historical={historical} forecast={forecast} modelId={activeModelId} />
          <ProjectionsLedger forecast={forecast} />
        </div>

        <div className="app-section-gap" />

        <div className="app-section-header">SHAP Feature Analysis</div>
        <ShapPanel shap={shap} />
      </main>
    </div>
  );
}
