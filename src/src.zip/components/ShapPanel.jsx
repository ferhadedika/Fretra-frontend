import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  ReferenceLine,
} from "recharts";
import "../styles/shap.css";

export function ShapPanel({ shap }) {
  if (!shap) return null;

  const globalData = [...shap.global_importance]
    .slice(0, 8)
    .sort((a, b) => a.value - b.value);

  const localData = [...shap.local_importance]
    .slice(0, 8)
    .sort((a, b) => a.value - b.value);

  return (
    <div className="shap-grid">
      <div className="chart-card">
        <div className="chart-card__title">Global Feature Importance</div>
        <div className="chart-card__sub">Mean |SHAP| — what matters across all forecasts</div>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={globalData} layout="vertical" margin={{ left: 8, right: 16 }}>
            <CartesianGrid stroke="#1e2d4a" strokeWidth={0.5} horizontal={false} />
            <XAxis type="number" tick={{ fill: "#4f6180", fontSize: 10 }} axisLine={{ stroke: "#1e2d4a" }} />
            <YAxis
              type="category"
              dataKey="label"
              tick={{ fill: "#8ba0be", fontSize: 11 }}
              width={150}
              axisLine={{ stroke: "#1e2d4a" }}
            />
            <Tooltip
              contentStyle={{ background: "#16213d", border: "1px solid #2a3a5c", borderRadius: 8 }}
              labelStyle={{ color: "#e8ecf4" }}
              itemStyle={{ color: "#c4cee0" }}
            />
            <Bar dataKey="value" radius={[0, 4, 4, 0]}>
              {globalData.map((entry, i) => (
                <Cell key={i} fill="#2171f5" />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="chart-card">
        <div className="chart-card__title">Local Decision Explanation</div>
        <div className="chart-card__sub">What drove this specific forecast</div>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={localData} layout="vertical" margin={{ left: 8, right: 16 }}>
            <CartesianGrid stroke="#1e2d4a" strokeWidth={0.5} horizontal={false} />
            <XAxis type="number" tick={{ fill: "#4f6180", fontSize: 10 }} axisLine={{ stroke: "#1e2d4a" }} />
            <YAxis
              type="category"
              dataKey="label"
              tick={{ fill: "#8ba0be", fontSize: 11 }}
              width={150}
              axisLine={{ stroke: "#1e2d4a" }}
            />
            <Tooltip
              contentStyle={{ background: "#16213d", border: "1px solid #2a3a5c", borderRadius: 8 }}
              labelStyle={{ color: "#e8ecf4" }}
              itemStyle={{ color: "#c4cee0" }}
            />
            <ReferenceLine x={0} stroke="#263454" />
            <Bar dataKey="value" radius={[0, 4, 4, 0]}>
              {localData.map((entry, i) => (
                <Cell key={i} fill={entry.value < 0 ? "#e2615f" : "#0d9e6a"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
