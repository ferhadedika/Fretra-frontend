import "../styles/kpi.css";

function fmt(value, decimals = 2, suffix = "") {
  if (value === null || value === undefined) return "N/A";
  return `${value.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}${suffix}`;
}

export function KpiRow({ forecast }) {
  if (!forecast) return null;

  const { current_scfi, forecast: points, model } = forecast;
  const wPlus1 = points[0];
  const wLast = points[points.length - 1];

  const w1Delta = wPlus1.forecast - current_scfi;
  const w1Pct = (w1Delta / current_scfi) * 100;

  const trajPct = ((wLast.forecast - current_scfi) / current_scfi) * 100;
  const trajLabel = trajPct >= 0 ? "Bullish outlook" : "Bearish outlook";

  return (
    <>
      <div className="kpi-grid kpi-grid--headline">
        <div className="kpi-card kpi-card--neutral">
          <div className="kpi-card__title">Current SCFI Index</div>
          <div className="kpi-card__value">{fmt(current_scfi)}</div>
          <div className="kpi-card__sub">Ground truth — {forecast.cutoff_date}</div>
        </div>

        <div className="kpi-card kpi-card--blue">
          <div className="kpi-card__title">W+1 Forecast</div>
          <div className="kpi-card__value kpi-card__value--blue">{fmt(wPlus1.forecast)}</div>
          <div className="kpi-card__sub">{model.label}</div>
          <div className={`kpi-card__delta ${w1Delta >= 0 ? "is-pos" : "is-neg"}`}>
            {w1Delta >= 0 ? "+" : ""}{fmt(w1Delta)} / {w1Pct >= 0 ? "+" : ""}{fmt(w1Pct, 2, "%")}
          </div>
        </div>

        <div className="kpi-card kpi-card--green">
          <div className="kpi-card__title">{points.length}-Week Trajectory</div>
          <div className={`kpi-card__value ${trajPct >= 0 ? "kpi-card__value--green" : ""}`}>
            {trajPct >= 0 ? "+" : ""}{fmt(trajPct, 1, "%")}
          </div>
          <div className="kpi-card__sub">Projected cumulative move</div>
          <div className={`kpi-card__delta ${trajPct >= 0 ? "is-pos" : "is-neg"}`}>{trajLabel}</div>
        </div>
      </div>

      <div className="kpi-grid kpi-grid--accuracy">
        <div className="kpi-card kpi-card--mini">
          <div className="kpi-card__title">MAE</div>
          <div className="kpi-card__value kpi-card__value--orange">{fmt(model.mae, 1)}</div>
          <div className="kpi-card__sub">Avg. error, original scale</div>
        </div>
        <div className="kpi-card kpi-card--mini">
          <div className="kpi-card__title">RMSE</div>
          <div className="kpi-card__value kpi-card__value--orange">{fmt(model.rmse, 1)}</div>
          <div className="kpi-card__sub">Penalizes large misses</div>
        </div>
        <div className="kpi-card kpi-card--mini">
          <div className="kpi-card__title">MAPE</div>
          <div className="kpi-card__value kpi-card__value--orange">{fmt(model.mape_pct, 2, "%")}</div>
          <div className="kpi-card__sub">Error as % of actual rate</div>
        </div>
        <div className="kpi-card kpi-card--mini">
          <div className="kpi-card__title">R²</div>
          <div className="kpi-card__value kpi-card__value--orange">{fmt(model.r2, 3)}</div>
          <div className="kpi-card__sub">Variance explained (0–1)</div>
        </div>
      </div>
    </>
  );
}
