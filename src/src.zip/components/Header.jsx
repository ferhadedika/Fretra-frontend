import "../styles/header.css";

export function Header({ firestoreMode }) {
  return (
    <header className="app-header">
      <div className="app-header__brand">
        <div className="app-header__logo">FA</div>
        <div>
          <div className="app-header__title">FREIGHTAI</div>
          <div className="app-header__subtitle">SCFI Rate Forecasting Engine</div>
        </div>
      </div>
      <div className="app-header__status">
        <span className="app-header__dot" />
        Live
        {firestoreMode && (
          <span className="app-header__mode" title="Forecast history storage backend">
            {firestoreMode}
          </span>
        )}
      </div>
    </header>
  );
}
