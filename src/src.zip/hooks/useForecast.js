import { useState, useCallback, useEffect } from "react";
import { fetchModels, fetchHistoricalSeries, runForecast, fetchShap } from "../services/api";

/**
 * hooks/useForecast.js
 * ======================
 * Owns all the async state for the main dashboard: available models,
 * historical series, the active forecast, and its SHAP explanation.
 * Keeping this in a hook (rather than inline in the page component)
 * means the loading/error states are handled once and consistently.
 */
export function useForecast() {
  const [models, setModels] = useState([]);
  const [historical, setHistorical] = useState([]);
  const [activeModelId, setActiveModelId] = useState("ensemble");
  const [horizonWeeks, setHorizonWeeks] = useState(8);
  const [forecast, setForecast] = useState(null);
  const [shap, setShap] = useState(null);

  const [loadingInitial, setLoadingInitial] = useState(true);
  const [loadingForecast, setLoadingForecast] = useState(false);
  const [error, setError] = useState(null);

  // Initial load: models + historical series
  useEffect(() => {
    let cancelled = false;
    async function init() {
      try {
        setLoadingInitial(true);
        const [modelsRes, historicalRes] = await Promise.all([
          fetchModels(),
          fetchHistoricalSeries(),
        ]);
        if (cancelled) return;
        setModels(modelsRes);
        setHistorical(historicalRes);
      } catch (err) {
        if (!cancelled) setError(err.message);
      } finally {
        if (!cancelled) setLoadingInitial(false);
      }
    }
    init();
    return () => {
      cancelled = true;
    };
  }, []);

  const generateForecast = useCallback(async (modelId = activeModelId, weeks = horizonWeeks) => {
    setLoadingForecast(true);
    setError(null);
    try {
      const [forecastRes, shapRes] = await Promise.all([
        runForecast({ modelId, horizonWeeks: weeks }),
        fetchShap(modelId, weeks),
      ]);
      setForecast(forecastRes);
      setShap(shapRes);
      setActiveModelId(modelId);
      setHorizonWeeks(weeks);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingForecast(false);
    }
  }, [activeModelId, horizonWeeks]);

  // Auto-run the first forecast once models + historical data are ready
  useEffect(() => {
    if (!loadingInitial && models.length > 0 && !forecast) {
      generateForecast(activeModelId, horizonWeeks);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadingInitial, models.length]);

  return {
    models,
    historical,
    activeModelId,
    horizonWeeks,
    forecast,
    shap,
    loadingInitial,
    loadingForecast,
    error,
    setHorizonWeeks,
    generateForecast,
  };
}
